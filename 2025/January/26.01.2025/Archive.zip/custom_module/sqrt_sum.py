from math import sqrt

def calc(*args):
    print(sqrt(sum(args)))

# calc(2, 54, 30, 72)
    