## Project Structure

📂 **pages**
- `login_page.py`
- `dashboard_page.py`

📂 **tests**
- `test_login.py`
- `test_dashboard.py`

📄 `conftest.py`