import ExtensionContainer from "./ExtensionContainer";
import MainHeader from "./MainHeader";

export default function Content () {
    return (
        <>  
            <MainHeader />
            <ExtensionContainer />
        </>
    )
}